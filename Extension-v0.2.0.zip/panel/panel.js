/* globals browser, chrome */
let accessor;
// Chrome and Firefox don't have the same entry point.
try {
    accessor = browser;
} catch (e) {
    accessor = chrome;
}

const $ = (query) => {
    return document.querySelectorAll(query);
};

const hasClass = (el, className) => {
    if (el.classList)
        return el.classList.contains(className);
    else
        return !!el.className.match(new RegExp('(\\s|^)' + className + '(\\s|$)'));
};

const addClass = (el, className) => {
    if (!className) {
        return;
    }

    if (typeof className === 'object') {
        className.forEach((cl) => addClass(el, cl));
        return;
    }

    if (el.classList)
        el.classList.add(className);
    else if (!hasClass(el, className))
        el.className += " " + className;
};

const removeClass = (el, className) => {
    if (!className) {
        return;
    }

    if (typeof className === 'object') {
        className.forEach((cl) => removeClass(el, cl));
        return;
    }

    if (el.classList)
        el.classList.remove(className);
    else if (hasClass(el, className)) {
        var reg = new RegExp('(\\s|^)' + className + '(\\s|$)');
        el.className=el.className.replace(reg, ' ');
    }
};

const req = (url, cb) => {
    const req = new XMLHttpRequest();

    req.onreadystatechange = (event) => {
        const target = event.target;
        if (target.readyState === XMLHttpRequest.DONE) {
            if (target.status === 200) {
                return cb();
            } else {
                return cb(target);
            }
        }
    };

    req.onError = (evt) => {
        cb(evt);
    };

    req.open('GET', `http://127.0.0.1:23489/open?url=${encodeURIComponent(url)}`, true);
    req.send(null);
};

const $info = $('#container .info-container')[0];
const $message = $('#container .spinner .text')[0];
const $retry = $('#container .spinner .retry')[0];

const changeState = (message, state) => {
    removeClass($info, ['loading', 'error', 'success']);
    addClass($info, state);
    $message.innerHTML = message;
};

let latestUrl;
const accessUrl = (url) => {
    changeState('Opening in Fenêtre.', 'loading');
    latestUrl = url;
    req(url, (err) => {
        if (err) {
            changeState('An error occured,<br/>is Fenêtre running?', 'error');
        } else {
            changeState('Opened in Fenêtre', 'success');
            setTimeout(() => {
                accessor.tabs.query({
                    currentWindow: true,
                    active: true
                }, (tabs) => {
                    accessor.windows.remove(tabs[0].windowId);
                });
            }, 2000);
        }
    });
}

$retry.addEventListener('click', () => {
    if (latestUrl) {
        accessUrl(latestUrl);
    }
});

accessor.runtime.onMessage.addListener(({ url }) => {
    accessUrl(url);
});
