/* globals browser, chrome */
let accessor;
// Chrome and Firefox don't have the same entry point.
try {
    accessor = browser;
} catch (e) {
    accessor = chrome;
}

const openPage = () => {
    accessor.tabs.query(
        {active: true, currentWindow: true},
        (tabs) => {
            openWindow(tabs[0].url);
        }
    );
};

let latestWindow;

accessor.windows.onRemoved.addListener((windowId) => {
    if (latestWindow && windowId === latestWindow.id) {
        latestWindow = undefined;
    }
});

const openWindow = (url) => {
    if (latestWindow) {
        accessor.windows.update(latestWindow.id, {
            focused: true
        });
        accessor.tabs.sendMessage(latestWindow.tabs[0].id, {url});
        return;
    }

    accessor.windows.create({
        width: 300,
        height: 300,
        url: 'panel/panel.html',
        type: 'panel'
    }, (win) => {
        latestWindow = win;
        setTimeout(() => {
            accessor.tabs.sendMessage(win.tabs[0].id, {url});
        }, 100);
    });
};

// Need to remove all first otherwise
// chrome throws an error if create two with the same id
accessor.contextMenus.removeAll(() => {
    accessor.contextMenus.create({
        id: 'fenetre-link',
        title: 'Open in Fenêtre',
        contexts: ['link']
    }, () => {
        accessor.contextMenus.onClicked.addListener(({linkUrl}) => {
            openWindow(linkUrl);
        });
    });
});

accessor.browserAction.onClicked.addListener(openPage);
