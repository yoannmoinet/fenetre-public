/* globals browser, chrome */
let accessor;
// Chrome and Firefox don't have the same entry point.
try {
    accessor = browser;
} catch (e) {
    accessor = chrome;
}

const openInFenetre = (url) => {
    console.log('OPEN #1', url);
    url = 'fenetre://' + encodeURIComponent(url);
    console.log('OPEN #2', url);
    // Need to use a callback instead of promise because of chrome
    accessor.tabs.create({ url }, (tab) => {
        // Need the timeout for Chrome, otherwise it won't open Fenêtre
        setTimeout(() => {
            accessor.tabs.remove(tab.id);
        }, 500);
    });
};

const openPage = () => {
    accessor.tabs.query(
        {active: true, currentWindow: true},
        (tabs) => {
            openInFenetre(tabs[0].url);
        }
    );
};

// Need to remove all first otherwise
// chrome throws an error if create two with the same id
accessor.contextMenus.removeAll(() => {
    accessor.contextMenus.create({
        id: 'fenetre-link',
        title: 'Open in Fenêtre',
        contexts: ['link']
    }, () => {
        accessor.contextMenus.onClicked.addListener(({linkUrl}) => {
            openInFenetre(linkUrl);
        });
    });
});

accessor.browserAction.onClicked.addListener(openPage);
